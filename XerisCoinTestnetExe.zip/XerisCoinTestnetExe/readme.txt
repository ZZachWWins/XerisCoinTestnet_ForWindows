================================================================
             XERISCOIN TESTNET - WINDOWS GUIDE
================================================================

WELCOME!
You are running a node for the XerisCoin network. This program will 
sync with the blockchain and mine coins automatically.

--- 1. HOW TO START ---
1. Create a folder on your Desktop named "Xeris".
2. Put the 'xrs-node.exe' file inside that folder.
3. Open PowerShell (Search "PowerShell" in the Start Menu).
4. Type these commands to go to your folder and start:

   cd Desktop\Xeris
   .\xrs-node.exe --validator 138.197.116.81 miner.json ledger.dat

   (You will see logs scrolling. This means it is working!)


--- 2. CHECK YOUR STATUS (THE "RACE CHECK") ---
Open a NEW PowerShell window and paste this to see if you are synced:

   Write-Host "🌍 Server Status:"; (Invoke-RestMethod "http://138.197.116.81:56001/blocks") | Select-Object -Last 1 -ExpandProperty slot
   Write-Host "💻 Your Node:";    (Invoke-RestMethod "http://127.0.0.1:56001/blocks")    | Select-Object -Last 1 -ExpandProperty slot

   * If numbers are close (e.g., 6700 and 6695), you are synced!


--- 3. GET YOUR WALLET ADDRESS ---
You need this address to receive coins. Run this in PowerShell:

   Get-Content miner.json


--- 4. GET FREE COINS (AIRDROP) ---
Replace YOUR_ADDRESS below with the address you found in Step 3.
Paste this into PowerShell:

   Invoke-RestMethod -Uri "http://127.0.0.1:56001/airdrop/YOUR_ADDRESS/100000"


--- 5. START MINING (STAKE) ---
You cannot mine until you stake your coins. 
Replace YOUR_ADDRESS below and paste this into PowerShell:

   $body = @{ pubkey = "YOUR_ADDRESS"; amount = 50000 } | ConvertTo-Json
   Invoke-RestMethod -Uri "http://127.0.0.1:56001/stake" -Method Post -Body $body -ContentType "application/json"

   * Wait 20 seconds. Check your node window. 
   * If you see "Block proposed and COMMITTED", you are mining!


--- TROUBLESHOOTING ---
If your node gets stuck or stops downloading for a long time:
1. Close the node window (Ctrl+C).
2. Delete the 'ledger.dat' file in your folder.
3. Restart the node. It will auto-repair.

